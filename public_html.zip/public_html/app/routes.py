#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from app import app
from hashlib import blake2b
from flask import render_template, request, url_for, redirect, session
import json
import os
import sys
import random

''' ############################## FUNCIONES ######################### '''



app.secret_key = 'esto-es-una-clave-muy-secreta'


@app.route("/aumentarSaldo", methods=['POST'])
def aumentarSaldo():
    saldo = request.form['saldo']
    print(saldo)
    saldo = int(saldo)
    userName = session['user']

    if saldo <= 0:
        return "0"

    fileName = "public_html/usuarios/%s/datos.dat" % userName

    with open(fileName, 'r') as file:
        lines = file.readlines()

    saldo += int(lines[4][7:])
    lines[4] = "Saldo: %d\n" % saldo

    with open(fileName, "w") as file:
        file.writelines(lines)

    return "1"


@app.route("/cargarCounter", methods=['POST'])
def loadCounter():
    id = int(request.form['movie_id'])
    id -= 1
    counter = session[str(id)]
    session[str(id)] = counter
    return str(counter)


@app.route("/addMovie", methods=['POST'])
def addMovie():
    if request.method == "POST":
        id = int(request.form["movie_id"])
        id -= 1
        amount = int(request.form["number"])
        session[str(id)] = amount
    return "4"


def checkUserOnline():
    if "user" in session:
        return session["user"]
    return None


def createUser() -> bool:
    userName = request.form['userName']
    password = request.form['password']
    email = request.form['email']
    creditCard = request.form['creditCard']
    address = request.form['address']

    dir_path = "public_html/usuarios/%s" + user

    try:
        os.makedirs(dir_path, exist_ok=False)
    except FileExistsError:
        return False

    with open(dir_path + "/datos.dat", 'w') as file:
        file.write('UserName: ' + userName + '\n')
        encrypted_password = hashlib.blake2b(
            password.encode('utf-8')).hexdigest()
        file.write('Password: ' + encrypted_password + '\n')
        file.write('Email: ' + email + '\n')
        file.write('CreditCard: ' + creditCard + '\n')
        file.write('Saldo: %d \n' % (100 * random.random()))
        file.write('Dirección: %s' % address)
    return True


def validateLogin() -> bool:
    userName = request.form['userName']
    password = request.form['password']

    try:
        file = open('public_html/usuarios/%s/datos.dat' % userName)
        data = file.readlines()
    except OSError:
        return False

    encrypted_password = hashlib.blake2b(
        password.encode('utf-8')).hexdigest()
    if userName == data[0][10:-1] and encrypted_password == data[1][10:-1]:
        return True
    else:
        return False


def addToCart(peliculas) -> None:
    films = session["films"]
    id = int(request.form['movie_id'])
    id -= 1
    film = peliculas[id]
    if film not in films:
        films.append(film)
        session["films"] = films
        session[str(id)] = 1
    else:
        num = session[str(id)]
        num += 1
        session[str(id)] = num
    
def readJSON():

    try:
        catalogue_data = open(os.path.join(app.root_path,'catalogue/inventario.json'), encoding="utf-8").read()
        catalogue = json.loads(catalogue_data)
        return catalogue['peliculas']
    except OSError:
        return None
    
def readJSONlista(jsonToRead):

    try:
        file = open(jsonToRead, encoding='UTF-8')
        catalogue_data = file.read()
        catalogue = json.loads(catalogue_data)
        return catalogue['peliculas']
    except OSError:
        return None

def filterByTitle(titulo,catalogue):
    films_filtered = list()

    for film in catalogue:
        if titulo.lower() in film['titulo'].lower():
            films_filtered.append(film)

    return films_filtered


''' ########################## RUTAS ####################### '''
@app.route('/', methods=['GET', 'POST'])
@app.route('/index', methods=['GET', 'POST'])
def index():
    # Si se ha usado la barra de busqueda
    if request.method=='POST':
        titulo = request.form["filter"]
        films = readJSON()
        catalogue = filterByTitle(titulo,films)
        return render_template('index.html', title = "Home", movies=catalogue)
    else:        
        print (url_for('static', filename='css/si1.css'), file=sys.stderr)
        catalogue_data = open(os.path.join(app.root_path,'catalogue/inventario.json'), encoding="utf-8").read()
        catalogue = json.loads(catalogue_data)
        return render_template('index.html', title = "Home", movies=catalogue['peliculas'])

@app.route('/login', methods=['GET', 'POST'])
def login():
    # doc sobre request object en http://flask.pocoo.org/docs/1.0/api/#incoming-request-data
    if 'username' in request.form:
        # aqui se deberia validar con fichero .dat del usuario
        if request.form['username'] == 'pp':
            session['usuario'] = request.form['username']
            session.modified=True
            # se puede usar request.referrer para volver a la pagina desde la que se hizo login
            return redirect(url_for('index'))
        else:
            # aqui se le puede pasar como argumento un mensaje de login invalido
            return render_template('login.html', title = "Sign In")
    else:
        # se puede guardar la pagina desde la que se invoca 
        session['url_origen']=request.referrer
        session.modified=True        
        # print a error.log de Apache si se ejecuta bajo mod_wsgi
        print (request.referrer, file=sys.stderr)
        return render_template('login.html', title = "Sign In")

@app.route("/film/<id>")
def film(id):
    films = readJSON()
    for item in films:
        if (str(item['id']) == id):
            print('hola')
            film = item
            break
        
    return render_template("filmDetail.html", movie=film, actors=film['actores'], user=checkUserOnline())

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.pop('usuario', None)
    return redirect(url_for('index'))

@app.route("/register")
def register():
    return render_template("register.html")

@app.route("/<categoria>")
def filterByCategory(categoria):

    films_filtered = list()

    films = readJSON()

    for film in films:
        if film['categoria'] == categoria:
            films_filtered.append(film)

    return render_template("index.html", movies=films_filtered, user=checkUserOnline())

@app.route("/cart", methods=['GET', 'POST'])
def cart():

    lista = session["films"]

    if request.method == "POST":
        id = request.form['id']
        for film in lista:
            if int(film['id']) == int(id):
                lista.remove(film)
                session["film"] = lista

    return render_template("cart.html", lista=lista, user=checkUserOnline())

@app.route("/historial")
def historial():
    user = session["user"]
    dir_Path = "public_html/usuarios/%s/" % user
    json_file = dir_Path + "historial.json"
    historial = readJSONlista(json_file)
    userData = dir_Path + "datos.dat"
    with open(userData, "r") as file:
        lines = file.readlines()
    saldo = lines[4][7:]
    return render_template("historial.html", historial=historial, saldo=saldo, user=checkUserOnline())

@app.route("/success")
def success():

    user = session["user"]
    dir_path = "public_html/usuarios/" + user

    films_list = session["films"]
    films = {"peliculas": films_list}
    json_file = dir_path + '/historial.json'

    data = None
    if os.path.exists(json_file) is True:
        with open(json_file, 'r') as file:
            data = json.load(file)
        for film in films["peliculas"]:
            if film in data["peliculas"] is False:
                data["peliculas"].append(film)
    else:
        data = films

    with open(json_file, 'w') as file:
        json.dump(data, file, indent=4)

    with open(dir_path + "/datos.dat", "r") as file:
        lines = file.readlines()

    saldo = lines[4]
    saldoDisponible = int(saldo[7:])

    precioUnaPelicula = 0.00
    cantidadPelicula = 0
    precioVariasPeliculas = 0.00
    precioTotal = 0.00

    for movie in films_list:
        precioUnaPelicula = movie['precio']
        idPelicula = str(movie['id'] - 1)
        cantidadPelicula = session[idPelicula]
        precioVariasPeliculas = precioUnaPelicula * cantidadPelicula
        precioTotal += precioVariasPeliculas

    if saldoDisponible > precioTotal:
        saldoDisponible -= precioTotal
        lines[4] = "Saldo: %d \n" % saldoDisponible
        with open(dir_path + "/datos.dat", "w") as file:
            file.writelines(lines)

    for film in films_list:
        id = str(film['id'] - 1)
        session.pop(id, None)
    session.pop("films", None)

    return render_template('success.html'), {"Refresh": "1; url=/"}


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5001, debug=True)
